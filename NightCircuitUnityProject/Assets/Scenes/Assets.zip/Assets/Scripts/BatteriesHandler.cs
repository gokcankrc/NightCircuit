using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BatteriesHandler : Singleton<BatteriesHandler>
{
    public void FlushBatteries()
    {
        // put all batteries back in their places
    }
}
